﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MyWizard.DomainModel;

namespace MyMvcWizard.Controllers
{
    public class WizardController : Controller
    {
        //
        // GET: /Wizard/
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }


        //
        // POST: /Wizard/
        [HttpPost]
        public ActionResult Index(User Person)
        {
            if (ModelState.IsValid)
                return View("Complete", Person);

            return View();
        }


        //
        // POST: /Wizard/Confirm
        [HttpPost]
        public ActionResult Confirm(User Person)
        {           
            return PartialView(Person);            
        }




    }
}
