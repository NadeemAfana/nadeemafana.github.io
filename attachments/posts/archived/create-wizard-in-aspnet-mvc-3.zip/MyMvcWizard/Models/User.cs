﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MyWizard.DomainModel
{
    public class User
    {
        [Required(ErrorMessage="Username  required.")]
        [StringLength(20, ErrorMessage="Username must be under 20 chars.")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "First name required.")]
        [StringLength(50, ErrorMessage = "First name must be under 50 chars.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last name required.")]
        [StringLength(50, ErrorMessage = "Last name must be under 50 chars.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Age required.")]
        [Range(0, 140, ErrorMessage="Age must be between 0 and 140")]
        public short Age { get; set; }


        [Required(ErrorMessage = "Email required.")]
        [RegularExpression(".+@.+\\..+", ErrorMessage = "Email not valid.")]
        public string Email { get; set; }

        [StringLength(1000, ErrorMessage = "Biography must be under 1000 chars.")]
        public string Biography { get; set; }
    }
}