﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace EFMultipleResultSets
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var context = new pubsEntities())
            {

                var pubs = context.publishers.Include("titles").Take(3).ToList();  // Take only 3 publishers

                foreach (var p in pubs)
                {
                    Console.WriteLine("{0} has published the following titles:", p.pub_name);
                    foreach (var t in p.titles)
                    {
                        Console.WriteLine("\t" + t.Title);
                    }

                }
                

            }

        }
    }


}

