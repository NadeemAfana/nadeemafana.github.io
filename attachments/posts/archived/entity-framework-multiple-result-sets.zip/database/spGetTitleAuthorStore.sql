USE [pubs]
GO

/****** Object:  StoredProcedure [dbo].[spGetTitleAuthorStore]    Script Date: 11/03/2010 23:18:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE proc [dbo].[spGetTitleAuthorStore]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   -- 1st set: Top 10 titles (by sales count)
   select top 10 * from titles order by ytd_sales desc
   
   -- 2nd set: All authors from California state.
   select * from authors where state='CA' 
   
   -- 3rd set: Top 10 stores (by sales total)
   select top 10 st.*, SUM(s.qty*t.price) as total from stores st inner join sales s on st.stor_id = s.stor_id
													 inner join titles t ON t.title_id=s.title_id 
													 group by st.stor_id, stor_name, stor_address, city, state ,zip
													 order by total desc 

   
END

GO


