﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace EFMultipleResultSets
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var context = new pubsEntities())
            {

                var cs = @"Data Source=.;Initial Catalog=pubs;Integrated Security=True";
                var conn = new SqlConnection(cs);
                var cmd = conn.CreateCommand();

                

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "dbo.spGetTitleAuthorStore";

                cmd.Connection.Open();

                var reader = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                var titles = context.Translate<title>(reader).ToList();
                reader.NextResult();
                var authors = context.Translate<author>(reader).ToList();
                reader.NextResult();
                var stores = context.Translate<store>(reader).ToList();


                Console.WriteLine("1st set: Top 10 titles (by sales count):");
                Console.WriteLine(new string('=', 50)); // line separator

                int i = 1;
                foreach (var t in titles)
                    Console.WriteLine("{0}. {1}", i++, t.Title);

                Console.WriteLine(new string('-', 50)); // line separator


                Console.WriteLine("2nd set: All authors from California state):");
                Console.WriteLine(new string('=', 50)); // line separator
                i = 1;
                foreach (var a in authors)
                    Console.WriteLine("{0}. {1}", i++, a.au_fname + " " + a.au_lname);


                Console.WriteLine(new string('-', 50)); // line separator

                Console.WriteLine("3rd set: Top 10 stores (by sales total amount):");
                Console.WriteLine(new string('=', 50)); // line separator
                i = 1;
                foreach (var s in stores)
                    Console.WriteLine("{0}. {1} in {2},{3}", i++, s.stor_name, s.city, s.state);


            }

        }
    }


}

